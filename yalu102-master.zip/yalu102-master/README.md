# yalu102

![Yalu logo](https://github.com/kpwn/yalu102/blob/master/yalu102/Assets.xcassets/AppIcon.appiconset/AppIcon60x60@3x.png?raw=true)

A "work in progress" iOS jailbreak for 64-bit devices created by [qwertyoruiopz](https://twitter.com/qwertyoruiopz) and [marcograssi](marcograss).

Please use the "Issues" tab for **code related** issues only. If you need support please search on [/r/jailbreak](https://reddit.com/r/jailbreak) before posting a question there.

## Supported Devices and iOS versions

| Device | Version | 
|---------|----------|
| iPad Pro  | iOS 10.0.0 -> iOS 10.2 |
| iPhone 6S  | iOS 10.0.0 -> iOS 10.2 |
| iPhone SE  | iOS 10.0.0 -> iOS 10.2 |

### Planned Support:

In the near future, the jailbreak will support the following devices:

| Device | Version | 
|---------|----------|
| iPhone 5S  | iOS 10.0.0 -> iOS 10.2 |
| iPad Air| iOS 10.0.0 -> iOS 10.2 |
| iPad Mini 2| iOS 10.0.0 -> iOS 10.2 |
| iPhone 6  | iOS 10.0.0 -> iOS 10.2 |
| iPad Air 2| iOS 10.0.0 -> iOS 10.2 |
| iPad Mini 3| iOS 10.0.0 -> iOS 10.2 |
| iPod touch (6G)  | iOS 10.0.0 -> iOS 10.2 |
| iPad Mini 4 | iOS 10.0.0 -> iOS 10.2 |
| iPhone 7  | iOS 10.0.0 -> iOS 10.1.1 |

**Note, the iPhone 7 is only supported till iOS 10.1.1**
If you are already on iOS 10.2 with an iPhone 7, **stay there**. The actual exploit behind this still works, but the KPP bypass does not.

## Compiling:

1. `git clone` the repo.
2. Open the repo in Xcode
3. Change the bundle ID, as shown [here](https://www.reddit.com/r/sideloaded/wiki/how-to-sideload#wiki_changing_the_bundle_identifier_and_team)
4. Include the IOKit headers, and add them to your search path.
5. Run the project.

## Installing

> DO NOT DOWNLOAD THIS SOFTWARE FROM OTHER SOURCES OTHER THAN THESE LINKS UNDER ANY CIRCUMSTANCE. IT IS VERY EASY TO BACKDOOR THIS SORT OF SOFTWARE TO CONTAIN MALWARE. PLEASE BE EXTREMELY CAREFUL. THESE MIRRORS ARE TRUSTED, BUT STILL CHECK THE SHA1.

* Download the pre-compiled version from the table below.
* [Check the SHA1 hash](http://onlinemd5.com) of the downloaded file (optional but recommended).
* Install using [Cydia Impactor](http://www.cydiaimpactor.com/).
* Open the application and follow instructions.
    

| Version | Download | SHA1 |
|---------|----------|------|
| Alpha  | [Link](https://yalu.qwertyoruiop.com/yalu102_alpha.ipa) | 2FE14F1C1E1A0D26203BBB123F6747A978DD2B4F  |

## Contributing

Create a fork of the repository, make your changes and then create a pull request.
Please be sure to check if the pull request has been made before, before creating a new one. Note, any pull requests adding IOKit headers will be closed. Please respect copyright laws, and do not distribute / download IOKit headers from unofficial sources: they are bundled legally with macOS SDK

